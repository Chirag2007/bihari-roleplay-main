Discord : https://discord.gg/C3aN2bBVbB

<img src="https://i.imgur.com/dAXlTSs.png">

Vidéo : https://youtu.be/AD0ieZUmFAE
